# 성호의 가계 - 알림 수신 테스트 1차

이 버전은 Android NotificationListenerService를 사용해 휴대폰에 표시되는 알림의 앱 패키지명, 제목, 내용, 시간을 로컬에 저장합니다.

## 테스트 순서
1. APK 설치
2. 앱 실행 → `알림 접근 권한 열기`
3. Android 설정에서 `성호의 가계 알림 수신` 허용
4. 카드/은행 알림 수신
5. 앱으로 돌아와 `새로고침`

첫 단계에서는 알림을 금융 거래로 자동 반영하지 않습니다. 원문 수신이 안정적인지 확인한 뒤 파싱/분류를 추가합니다.

## GitHub Actions 빌드
`.github/workflows/android-debug-apk.yml` 포함. 저장소에 프로젝트 전체를 올리면 Actions에서 Debug APK를 생성합니다.
