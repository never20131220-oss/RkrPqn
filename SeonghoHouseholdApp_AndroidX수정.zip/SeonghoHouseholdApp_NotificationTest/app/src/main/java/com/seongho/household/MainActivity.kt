package com.seongho.household

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView

    inner class AndroidBridge {
        @JavascriptInterface fun openNotificationAccess() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        }
        @JavascriptInterface fun getNotifications(): String = NotificationStore.json(this@MainActivity)
        @JavascriptInterface fun clearNotifications() { NotificationStore.clear(this@MainActivity) }
        @JavascriptInterface fun isNotificationAccessEnabled(): Boolean {
            val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
            return enabled.contains(packageName)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        web = findViewById(R.id.web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(AndroidBridge(), "AndroidApp")
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) web.evaluateJavascript("window.refreshNotificationTest && window.refreshNotificationTest();", null)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
}
