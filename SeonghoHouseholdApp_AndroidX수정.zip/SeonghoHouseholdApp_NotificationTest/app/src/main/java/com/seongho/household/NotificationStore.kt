package com.seongho.household

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object NotificationStore {
    private const val PREFS = "notification_capture"
    private const val KEY = "items"
    private const val MAX_ITEMS = 100

    fun add(context: Context, packageName: String, title: String, text: String, postedAt: Long) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val current = try { JSONArray(prefs.getString(KEY, "[]")) } catch (_: Exception) { JSONArray() }
        val fingerprint = "$packageName|$title|$text|${postedAt / 60000}"
        for (i in 0 until current.length()) {
            if (current.optJSONObject(i)?.optString("fingerprint") == fingerprint) return
        }
        val next = JSONArray()
        next.put(JSONObject().apply {
            put("packageName", packageName)
            put("title", title)
            put("text", text)
            put("postedAt", postedAt)
            put("fingerprint", fingerprint)
        })
        for (i in 0 until minOf(current.length(), MAX_ITEMS - 1)) next.put(current.get(i))
        prefs.edit().putString(KEY, next.toString()).apply()
    }

    fun json(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, "[]").apply()
    }
}
